create view needrep as
select `ewsdb`.`tb_equ`.`e_id`             AS `e_id`,
       `ewsdb`.`tb_equ`.`snumber`          AS `snumber`,
       `ewsdb`.`tb_equ`.`iname`            AS `iname`,
       `ewsdb`.`tb_equ`.`itype`            AS `itype`,
       `ewsdb`.`tb_equ`.`dept`             AS `dept`,
       `ewsdb`.`tb_equ`.`iproducetime`     AS `iproducetime`,
       `ewsdb`.`tb_equ`.`istarttime`       AS `istarttime`,
       `ewsdb`.`tb_equ`.`repaircycle`      AS `repaircycle`,
       `ewsdb`.`tb_equ`.`latestrepairtime` AS `latestrepairtime`,
       `ewsdb`.`tb_equ`.`istate`           AS `istate`,
       `ewsdb`.`tb_equ`.`manu`             AS `manu`,
       `ewsdb`.`tb_equ`.`tel`              AS `tel`
from `ewsdb`.`tb_equ`
where ((to_days(now()) - to_days(`ewsdb`.`tb_equ`.`latestrepairtime`)) >
       substring_index(`ewsdb`.`tb_equ`.`repaircycle`, '天', 1));

